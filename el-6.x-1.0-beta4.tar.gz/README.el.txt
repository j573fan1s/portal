HELLENIC (GREEK) TRANSLATION FOR DRUPAL 6
=========================================
This is work in progress. If you are interested, you can join us at
http://drupal-el.berlios.de
or visit the translation's homepage at
http://drupal.org/project/el

For any comments, please file an issue at
http://drupal.org/node/add/project_issue/el/bug

Thank you.
